// Banco de dados de pessoas da família (exemplo)
let familyDatabase = [
    {
        name: "Vovô João",
        description: "O patriarca carinhoso que adora contar histórias",
        attributes: {
            genero: "masculino",
            idade: "idoso",
            parentesco: "avo",
            personalidade: "carinhoso",
            hobby: "contar-historias",
            mora_aqui: "sim",
            trabalha: "nao"
        }
    },
    {
        name: "Vovó Maria",
        description: "A cozinheira mais talentosa da família",
        attributes: {
            genero: "feminino",
            idade: "idosa",
            parentesco: "avo",
            personalidade: "carinhosa",
            hobby: "cozinhar",
            mora_aqui: "sim",
            trabalha: "nao"
        }
    },
    {
        name: "Papai",
        description: "O pai dedicado e trabalhador",
        attributes: {
            genero: "masculino",
            idade: "adulto",
            parentesco: "pai",
            personalidade: "dedicado",
            hobby: "trabalhar",
            mora_aqui: "sim",
            trabalha: "sim"
        }
    },
    {
        name: "Mamãe",
        description: "A mãe amorosa e cuidadosa",
        attributes: {
            genero: "feminino",
            idade: "adulta",
            parentesco: "mae",
            personalidade: "amorosa",
            hobby: "cuidar-familia",
            mora_aqui: "sim",
            trabalha: "sim"
        }
    },
    {
        name: "Tio Carlos",
        description: "O tio engraçado que sempre faz piadas",
        attributes: {
            genero: "masculino",
            idade: "adulto",
            parentesco: "tio",
            personalidade: "engracado",
            hobby: "fazer-piadas",
            mora_aqui: "nao",
            trabalha: "sim"
        }
    },
    {
        name: "Tia Ana",
        description: "A tia artista que pinta quadros lindos",
        attributes: {
            genero: "feminino",
            idade: "adulta",
            parentesco: "tia",
            personalidade: "artistica",
            hobby: "pintar",
            mora_aqui: "nao",
            trabalha: "sim"
        }
    },
    {
        name: "Nosso Pequeno Tesouro",
        description: "O bebê mais fofo que está completando 8 meses!",
        attributes: {
            genero: "masculino", // ou feminino, ajuste conforme necessário
            idade: "bebe",
            parentesco: "neto",
            personalidade: "fofo",
            hobby: "brincar",
            mora_aqui: "sim",
            trabalha: "nao"
        }
    }
];

// Perguntas do jogo
const questions = [
    {
        text: "🚹🚺 Essa pessoa é do sexo masculino?",
        attribute: "genero",
        value: "masculino"
    },
    {
        text: "👶 Essa pessoa é um bebê ou criança pequena?",
        attribute: "idade",
        value: "bebe"
    },
    {
        text: "👴👵 Essa pessoa é idosa (vovô ou vovó)?",
        attribute: "idade",
        value: "idoso"
    },
    {
        text: "🏠 Essa pessoa mora na mesma casa que vocês?",
        attribute: "mora_aqui",
        value: "sim"
    },
    {
        text: "💼 Essa pessoa trabalha fora de casa?",
        attribute: "trabalha",
        value: "sim"
    },
    {
        text: "👨‍👩‍👧‍👦 Essa pessoa é pai ou mãe?",
        attribute: "parentesco",
        value: "pai"
    },
    {
        text: "👴👵 Essa pessoa é avô ou avó?",
        attribute: "parentesco",
        value: "avo"
    },
    {
        text: "👨‍👩‍👧‍👦 Essa pessoa é tio ou tia?",
        attribute: "parentesco",
        value: "tio"
    },
    {
        text: "😄 Essa pessoa é conhecida por ser muito engraçada?",
        attribute: "personalidade",
        value: "engracado"
    },
    {
        text: "🍳 Essa pessoa adora cozinhar?",
        attribute: "hobby",
        value: "cozinhar"
    },
    {
        text: "📚 Essa pessoa gosta de contar histórias?",
        attribute: "hobby",
        value: "contar-historias"
    },
    {
        text: "🎨 Essa pessoa é artística (desenha, pinta, etc.)?",
        attribute: "hobby",
        value: "pintar"
    },
    {
        text: "🤱 Essa pessoa cuida muito bem da família?",
        attribute: "hobby",
        value: "cuidar-familia"
    },
    {
        text: "😂 Essa pessoa sempre faz piadas?",
        attribute: "hobby",
        value: "fazer-piadas"
    },
    {
        text: "🧸 Essa pessoa gosta de brincar?",
        attribute: "hobby",
        value: "brincar"
    }
];

// Estado do jogo
let gameState = {
    currentQuestionIndex: 0,
    possiblePeople: [...familyDatabase],
    askedQuestions: [],
    userAnswers: {}
};

// Elementos DOM
const screens = {
    welcome: document.getElementById('welcome-screen'),
    game: document.getElementById('game-screen'),
    result: document.getElementById('result-screen'),
    success: document.getElementById('success-screen'),
    addPerson: document.getElementById('add-person-screen')
};

const elements = {
    startGame: document.getElementById('start-game'),
    questionText: document.getElementById('question-text'),
    currentQuestion: document.getElementById('current-question'),
    totalQuestions: document.getElementById('total-questions'),
    progressFill: document.querySelector('.progress-fill'),
    answerButtons: document.querySelectorAll('.answer-btn'),
    guessName: document.getElementById('guess-name'),
    guessDescription: document.getElementById('guess-description'),
    correctGuess: document.getElementById('correct-guess'),
    wrongGuess: document.getElementById('wrong-guess'),
    playAgain: document.getElementById('play-again'),
    addPerson: document.getElementById('add-person'),
    skipAdd: document.getElementById('skip-add'),
    personName: document.getElementById('person-name'),
    personDescription: document.getElementById('person-description')
};

// Funções utilitárias
function showScreen(screenName) {
    Object.values(screens).forEach(screen => screen.classList.remove('active'));
    screens[screenName].classList.add('active');
}

function resetGame() {
    gameState = {
        currentQuestionIndex: 0,
        possiblePeople: [...familyDatabase],
        askedQuestions: [],
        userAnswers: {}
    };
    elements.progressFill.style.width = '0%';
}

function updateProgress() {
    const progress = (gameState.currentQuestionIndex / questions.length) * 100;
    elements.progressFill.style.width = `${Math.min(progress, 100)}%`;
    elements.currentQuestion.textContent = gameState.currentQuestionIndex + 1;
    elements.totalQuestions.textContent = questions.length;
}

function getNextQuestion() {
    // Encontrar a pergunta que melhor divide as possibilidades restantes
    let bestQuestion = null;
    let bestScore = -1;

    for (let i = 0; i < questions.length; i++) {
        if (gameState.askedQuestions.includes(i)) continue;

        const question = questions[i];
        const yesCount = gameState.possiblePeople.filter(person => 
            person.attributes[question.attribute] === question.value ||
            (question.attribute === "parentesco" && question.value === "pai" && 
             (person.attributes[question.attribute] === "pai" || person.attributes[question.attribute] === "mae"))
        ).length;
        
        const noCount = gameState.possiblePeople.length - yesCount;
        const score = Math.min(yesCount, noCount);

        if (score > bestScore) {
            bestScore = score;
            bestQuestion = i;
        }
    }

    return bestQuestion;
}

function filterPeopleByAnswer(questionIndex, answer) {
    const question = questions[questionIndex];
    
    gameState.possiblePeople = gameState.possiblePeople.filter(person => {
        const personValue = person.attributes[question.attribute];
        
        switch (answer) {
            case 'sim':
                if (question.attribute === "parentesco" && question.value === "pai") {
                    return personValue === "pai" || personValue === "mae";
                }
                return personValue === question.value;
            
            case 'nao':
                if (question.attribute === "parentesco" && question.value === "pai") {
                    return personValue !== "pai" && personValue !== "mae";
                }
                return personValue !== question.value;
            
            case 'nao-sei':
            case 'provavelmente':
            case 'provavelmente-nao':
                // Para respostas incertas, mantemos todas as possibilidades
                return true;
            
            default:
                return true;
        }
    });
}

function makeGuess() {
    if (gameState.possiblePeople.length === 1) {
        return gameState.possiblePeople[0];
    } else if (gameState.possiblePeople.length > 1) {
        // Retorna a pessoa mais provável (primeira da lista)
        return gameState.possiblePeople[0];
    } else {
        // Nenhuma pessoa restante, retorna uma pessoa aleatória
        return familyDatabase[Math.floor(Math.random() * familyDatabase.length)];
    }
}

function askQuestion() {
    if (gameState.possiblePeople.length <= 1 || gameState.currentQuestionIndex >= questions.length) {
        showGuess();
        return;
    }

    const questionIndex = getNextQuestion();
    if (questionIndex === null) {
        showGuess();
        return;
    }

    gameState.askedQuestions.push(questionIndex);
    elements.questionText.textContent = questions[questionIndex].text;
    updateProgress();

    // Adicionar animação ao gênio
    const genie = document.querySelector('.genie');
    genie.classList.add('thinking');
    playThinkingSound();
    setTimeout(() => genie.classList.remove('thinking'), 1000);
}

function showGuess() {
    const guess = makeGuess();
    elements.guessName.textContent = guess.name;
    elements.guessDescription.textContent = guess.description;
    showScreen('result');

    // Animação do gênio animado
    const genie = document.querySelector('.genie');
    genie.classList.add('excited');
}

// Event Listeners
elements.startGame.addEventListener('click', () => {
    resetGame();
    showScreen('game');
    askQuestion();
});

elements.answerButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        const answer = e.target.dataset.answer;
        const currentQuestionIndex = gameState.askedQuestions[gameState.askedQuestions.length - 1];
        
        gameState.userAnswers[currentQuestionIndex] = answer;
        filterPeopleByAnswer(currentQuestionIndex, answer);
        gameState.currentQuestionIndex++;
        
        // Adicionar efeito visual ao botão clicado
        e.target.style.transform = 'scale(0.95)';
        setTimeout(() => {
            e.target.style.transform = 'scale(1)';
        }, 150);
        
        setTimeout(() => {
            askQuestion();
        }, 500);
    });
});

elements.correctGuess.addEventListener('click', () => {
    playSuccessSound();
    addConfettiEffect();
    setTimeout(() => {
        showScreen('success');
    }, 500);
});

elements.wrongGuess.addEventListener('click', () => {
    showScreen('addPerson');
});

elements.playAgain.addEventListener('click', () => {
    showScreen('welcome');
});

elements.addPerson.addEventListener('click', () => {
    const name = elements.personName.value.trim();
    const description = elements.personDescription.value.trim();
    
    if (name && description) {
        // Aqui você poderia adicionar a nova pessoa ao banco de dados
        // Por simplicidade, apenas mostramos uma mensagem
        alert(`Obrigado! ${name} foi adicionado à nossa família virtual! 🎉`);
        elements.personName.value = '';
        elements.personDescription.value = '';
        showScreen('welcome');
    } else {
        alert('Por favor, preencha o nome e a descrição! 😊');
    }
});

elements.skipAdd.addEventListener('click', () => {
    showScreen('welcome');
});

// Funções de animação e efeitos
function addSparkleEffect(element) {
    const sparkle = document.createElement('div');
    sparkle.innerHTML = '✨';
    sparkle.style.position = 'absolute';
    sparkle.style.fontSize = '20px';
    sparkle.style.pointerEvents = 'none';
    sparkle.style.animation = 'sparkleFloat 1s ease-out forwards';
    
    const rect = element.getBoundingClientRect();
    sparkle.style.left = (rect.left + Math.random() * rect.width) + 'px';
    sparkle.style.top = (rect.top + Math.random() * rect.height) + 'px';
    
    document.body.appendChild(sparkle);
    
    setTimeout(() => {
        sparkle.remove();
    }, 1000);
}

function addConfettiEffect() {
    const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#ffeaa7', '#dda0dd'];
    
    for (let i = 0; i < 50; i++) {
        setTimeout(() => {
            const confetti = document.createElement('div');
            confetti.style.position = 'fixed';
            confetti.style.width = '10px';
            confetti.style.height = '10px';
            confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            confetti.style.left = Math.random() * window.innerWidth + 'px';
            confetti.style.top = '-10px';
            confetti.style.borderRadius = '50%';
            confetti.style.pointerEvents = 'none';
            confetti.style.animation = 'confettiFall 3s linear forwards';
            confetti.style.zIndex = '1000';
            
            document.body.appendChild(confetti);
            
            setTimeout(() => {
                confetti.remove();
            }, 3000);
        }, i * 50);
    }
}

function shakeElement(element) {
    element.style.animation = 'shake 0.5s ease-in-out';
    setTimeout(() => {
        element.style.animation = '';
    }, 500);
}

function pulseElement(element) {
    element.style.animation = 'pulse 0.6s ease-in-out';
    setTimeout(() => {
        element.style.animation = '';
    }, 600);
}

// Adicionar sons (usando Web Audio API para sons simples)
function playSound(frequency, duration) {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = frequency;
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + duration);
}

function playClickSound() {
    playSound(800, 0.1);
}

function playSuccessSound() {
    playSound(523, 0.2);
    setTimeout(() => playSound(659, 0.2), 100);
    setTimeout(() => playSound(784, 0.3), 200);
}

function playThinkingSound() {
    playSound(400, 0.1);
    setTimeout(() => playSound(450, 0.1), 150);
}

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    showScreen('welcome');
    
    // Adicionar animações aos olhos do gênio
    setInterval(() => {
        const eyes = document.querySelectorAll('.eye');
        eyes.forEach(eye => {
            eye.style.transform = 'scaleY(0.1)';
            setTimeout(() => {
                eye.style.transform = 'scaleY(1)';
            }, 150);
        });
    }, 3000);
    
    // Adicionar efeitos de hover aos botões
    document.querySelectorAll('button').forEach(button => {
        button.addEventListener('mouseenter', () => {
            addSparkleEffect(button);
        });
        
        button.addEventListener('click', () => {
            playClickSound();
            pulseElement(button);
        });
    });
    
    // Adicionar movimento dos olhos do gênio seguindo o mouse
    document.addEventListener('mousemove', (e) => {
        const eyes = document.querySelectorAll('.eye');
        eyes.forEach(eye => {
            const rect = eye.getBoundingClientRect();
            const eyeCenterX = rect.left + rect.width / 2;
            const eyeCenterY = rect.top + rect.height / 2;
            
            const angle = Math.atan2(e.clientY - eyeCenterY, e.clientX - eyeCenterX);
            const distance = Math.min(3, Math.sqrt(Math.pow(e.clientX - eyeCenterX, 2) + Math.pow(e.clientY - eyeCenterY, 2)) / 10);
            
            const pupilX = Math.cos(angle) * distance;
            const pupilY = Math.sin(angle) * distance;
            
            eye.style.transform = `translate(${pupilX}px, ${pupilY}px)`;
        });
    });
    
    // Adicionar efeito de digitação para o título
    const title = document.querySelector('.title');
    if (title) {
        const originalText = title.textContent;
        title.textContent = '';
        let i = 0;
        
        const typeWriter = () => {
            if (i < originalText.length) {
                title.textContent += originalText.charAt(i);
                i++;
                setTimeout(typeWriter, 100);
            }
        };
        
        setTimeout(typeWriter, 500);
    }
    
    // Adicionar partículas flutuantes
    setInterval(() => {
        const particle = document.createElement('div');
        particle.innerHTML = ['🎈', '🎉', '⭐', '💫', '🌟'][Math.floor(Math.random() * 5)];
        particle.style.position = 'fixed';
        particle.style.fontSize = '20px';
        particle.style.left = Math.random() * window.innerWidth + 'px';
        particle.style.top = window.innerHeight + 'px';
        particle.style.pointerEvents = 'none';
        particle.style.animation = 'floatUp 8s linear forwards';
        particle.style.zIndex = '1';
        
        document.body.appendChild(particle);
        
        setTimeout(() => {
            particle.remove();
        }, 8000);
    }, 2000);
});
